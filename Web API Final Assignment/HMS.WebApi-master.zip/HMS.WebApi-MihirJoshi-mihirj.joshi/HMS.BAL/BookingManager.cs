﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.DAL.Repository;
using HMS.Models;
using HMS.Models.Dtos;

namespace HMS.BAL
{
    public class BookingManager : IBookingManager
    {
        private readonly IBookingRepository _bookingRepository;

        public BookingManager(IBookingRepository bookingRepository)
        {
            _bookingRepository = bookingRepository;
        }

        public BookingDto GetBooking(int id)
        {
            return _bookingRepository.GetBooking(id);
        }

        public IQueryable<BookingDto> GetBookings()
        {
            return _bookingRepository.GetBookings();
        }

        public string BookRoom(int roomId, DateTime bookingDate)
        {
            return _bookingRepository.BookRoom(roomId, bookingDate);
        }

        public string UpdateBooking(int bookingId, DateTime updatedDate)
        {
            return _bookingRepository.UpdateBooking(bookingId, updatedDate);
        }

        public string UpdateBookingStatus(int id, Status bookingStatus)
        {
            return _bookingRepository.UpdateBookingStatus(id, bookingStatus);
        }

        public string DeleteBooking(int id)
        {
            return _bookingRepository.DeleteBooking(id);
        }
    }
}
