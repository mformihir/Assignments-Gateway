﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Models;
using HMS.DAL.Repository;
using HMS.Models.Dtos;

namespace HMS.BAL
{
    public class HotelManager : IHotelManager
    {
        private readonly IHotelRepository _hotelRepository;
        private readonly IRoomRepository _roomRepository;

        public HotelManager(IHotelRepository hotelRepository, IRoomRepository roomRepository)
        {
            _hotelRepository = hotelRepository;
            _roomRepository = roomRepository;
        }
        public HotelDto GetHotel(int id)
        {
            return _hotelRepository.GetHotel(id);
        }
        public IQueryable<HotelDto> GetHotels()
        {
            return _hotelRepository.GetHotels();
        }

        public string CreateHotel(HotelDto hotelDto)
        {
            string message = "";
            message += _hotelRepository.CreateHotel(hotelDto);
            return message;
        }
    }
}
