﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Models;
using HMS.Models.Dtos;

namespace HMS.BAL
{
    public interface IHotelManager
    {
        HotelDto GetHotel(int id);
        IQueryable<HotelDto> GetHotels();
        string CreateHotel(HotelDto hotel);
    }
}
