﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.DAL.Repository;
using HMS.Models;
using HMS.Models.Dtos;

namespace HMS.BAL
{
    public interface IRoomManager
    {
        RoomDto GetRoom(int id);
        IQueryable<RoomDto> GetRooms();
        IQueryable<RoomDto> GetRoomsByCity(string hotelCity);
        IQueryable<RoomDto> GetRoomsByPinCode(string pinCode);
        IQueryable<RoomDto> GetRoomsByPrice(decimal price);
        IQueryable<RoomDto> GetRoomsByCategory(Models.Category category);
        bool CheckAvailability(int roomId, DateTime checkDate);
        string CreateRoom(RoomDto roomDto);
    }
}
