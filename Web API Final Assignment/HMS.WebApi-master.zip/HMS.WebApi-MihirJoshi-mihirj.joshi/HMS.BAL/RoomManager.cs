﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.DAL.Repository;
using HMS.Models;
using HMS.Models.Dtos;

namespace HMS.BAL
{
    public class RoomManager : IRoomManager
    {
        private readonly IRoomRepository _roomRepository;

        public RoomManager(IRoomRepository roomRepository)
        {
            _roomRepository = roomRepository;
        }
        public RoomDto GetRoom(int id)
        {
            return _roomRepository.GetRoom(id);
        }

        public IQueryable<RoomDto> GetRooms()
        {
            return _roomRepository.GetRooms();
        }
        public IQueryable<RoomDto> GetRoomsByCity(string hotelCity)
        {
            return _roomRepository.GetRoomsByCity(hotelCity);
        }
        public IQueryable<RoomDto> GetRoomsByPinCode(string pinCode)
        {
            return _roomRepository.GetRoomsByPinCode(pinCode);
        }
        public IQueryable<RoomDto> GetRoomsByPrice(decimal price)
        {
            return _roomRepository.GetRoomsByPrice(price);
        }

        public IQueryable<RoomDto> GetRoomsByCategory(Models.Category category)
        {
            return _roomRepository.GetRoomsByCategory(category);
        }
        public string CreateRoom(RoomDto roomDto)
        {
            return _roomRepository.CreateRoom(roomDto);
        }
        public bool CheckAvailability(int roomId, DateTime checkDate)
        {
            return _roomRepository.CheckAvailability(roomId, checkDate);
        }
    }
}
