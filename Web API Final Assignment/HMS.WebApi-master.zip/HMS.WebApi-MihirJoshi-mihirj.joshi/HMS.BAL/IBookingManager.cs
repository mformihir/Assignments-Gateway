﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Models;
using HMS.Models.Dtos;

namespace HMS.BAL
{
    public interface IBookingManager
    {
        BookingDto GetBooking(int id);
        string BookRoom(int roomid, DateTime bookingDate);
        IQueryable<BookingDto> GetBookings();
        string UpdateBooking(int bookingId, DateTime updatedDate);
        string UpdateBookingStatus(int id, Status bookingStatus);
        string DeleteBooking(int id);
    }
}
