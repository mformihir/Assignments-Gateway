﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Models.Dtos
{
    public class HotelDto
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        [MaxLength(10)]
        public string PinCode { get; set; }

        [Required]
        [Phone]
        [MaxLength(15)]
        public string ContactNumber { get; set; }

        [Required]
        public string ContactPerson { get; set; }

        public string Website { get; set; }

        public string Facebook { get; set; }

        public string Twitter { get; set; }

        [Required]
        public bool IsActive { get; set; }

        public ICollection<RoomDto> Rooms { get; set; }
    }
}
