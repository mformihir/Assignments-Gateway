﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Models.Dtos
{
    public enum Category
    {
        /// <summary>
        /// Size < 35 m2
        /// </summary>
        Category1 = 1,

        /// <summary>
        /// Size 36-50 m2
        /// </summary>
        Category2 = 2,

        /// <summary>
        /// Size 51-100 m2
        /// </summary>
        Category3 = 3
    }

    public class RoomDto
    {
        public int Id { get; set; }

        public int HotelId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public Category Category { get; set; }

        [Required]
        public decimal Price { get; set; }

        public bool IsActive { get; set; }


        //Navigation Properties
        public ICollection<BookingDto> Bookings { get; set; }
    }
}
