﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HMS.Models.Dtos
{
    public class BookingDto
    {
        public int Id { get; set; }

        public int RoomId { get; set; }

        [Required]
        public DateTime Date { get; set; }
    }
}