﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HMS.Models
{
    public enum Category
    {
        /// <summary>
        /// Size < 35 m2
        /// </summary>
        Category1 = 1,

        /// <summary>
        /// Size 36-50 m2
        /// </summary>
        Category2 = 2,

        /// <summary>
        /// Size 51-100 m2
        /// </summary>
        Category3 = 3
    }

    public class Room
    {
        public int Id { get; set; }

        public int HotelId { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public Category Category { get; set; }

        [Required]
        public decimal Price { get; set; }

        public bool IsActive { get; set; }

        public DateTime? CreatedDate { get; set; }

        public int? CreatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public int? UpdatedBy { get; set; }


        //Navigation Properties
        public Hotel Hotel { get; set; }

        public ICollection<Booking> Bookings { get; set; }
    }
}