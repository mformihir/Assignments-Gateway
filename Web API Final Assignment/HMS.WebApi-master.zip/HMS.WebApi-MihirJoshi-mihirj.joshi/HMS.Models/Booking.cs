﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HMS.Models
{
    public enum Status
    {
        Optional,
        Definitive,
        Cancelled,
        Deleted
    }
    public class Booking
    {
        public int Id { get; set; }

        public int RoomId { get; set; }

        [Required]
        public DateTime Date { get; set; }

        public Status Status { get; set; }

        public Room Room { get; set; }
    }
}