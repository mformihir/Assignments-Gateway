﻿using System;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;
using HMS.BAL;
using HMS.Models;
using HMS.Models.Dtos;
using Category = HMS.Models.Category;

namespace HMS.WebApi.Controllers
{
    [Authorize]
    public class RoomsController : ApiController
    {
        private readonly IRoomManager _roomManager;

        public RoomsController(IRoomManager roomManager)
        {
            _roomManager = roomManager;
        }

        // GET: api/rooms
        public IHttpActionResult GetRooms()
        {
            var rooms = _roomManager.GetRooms();

            if (!rooms.Any())
                return NotFound();

            return Ok(rooms);
        }

        // GET: api/rooms/city/mumbai
        [Route("api/rooms/city/{hotelCity:alpha}")]
        public IHttpActionResult GetRoomsByCity(string hotelCity)
        {
            var rooms = _roomManager.GetRoomsByCity(hotelCity);

            if (!rooms.Any()) return NotFound();

            return Ok(rooms);
        }

        // GET: api/rooms/pincode/111222
        [Route("api/rooms/pincode/{pinCode:length(6,10)}")]
        public IHttpActionResult GetRoomsByPinCode(string pinCode)
        {
            var rooms = _roomManager.GetRoomsByPinCode(pinCode);

            if (!rooms.Any()) return NotFound();

            return Ok(rooms);
        }

        // GET: api/Rooms/price/100
        [Route("api/rooms/price/{price:decimal}")]
        public IHttpActionResult GetRoomsByPrice(decimal price)
        {
            var rooms = _roomManager.GetRoomsByPrice(price);

            if (!rooms.Any()) return NotFound();

            return Ok(rooms);
        }

        // GET: api/rooms/category/1
        [Route("api/rooms/category/{category:int}")]
        public IHttpActionResult GetRoomsByCategory(Category category)
        {
            var rooms = _roomManager.GetRoomsByCategory(category);

            if (!rooms.Any()) return NotFound();

            return Ok(rooms);
        }

        [Route("api/rooms/{roomId:int}/{date:datetime}")]
        [ResponseType(typeof(Room))]
        [HttpGet]
        public IHttpActionResult CheckRoom(int roomId, DateTime date)
        {
            try
            {
                bool isAvailable = _roomManager.CheckAvailability(roomId, date);

                return Ok(isAvailable);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return NotFound();
            }
        }

        // POST: api/rooms
        [ResponseType(typeof(Room))]
        public IHttpActionResult PostRoom(RoomDto roomDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            return Ok(_roomManager.CreateRoom(roomDto));
        }

    }
}