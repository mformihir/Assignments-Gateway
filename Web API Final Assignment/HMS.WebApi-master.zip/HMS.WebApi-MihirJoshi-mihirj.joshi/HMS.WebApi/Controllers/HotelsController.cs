﻿using System;
using System.Linq;
using System.Web.Http;
using HMS.BAL;
using HMS.Models.Dtos;

namespace HMS.WebApi.Controllers
{
    [Authorize]
    public class HotelsController : ApiController
    {
        private readonly IHotelManager _hotelManager;

        public HotelsController(IHotelManager hotelManager)
        {
            _hotelManager = hotelManager;
        }

        // GET: api/hotels
        public IHttpActionResult Get()
        {
            var hotels = _hotelManager.GetHotels();

            if (!hotels.Any())
                return NotFound();

            return Ok(hotels);
        }

        // GET: api/hotels/5
        public IHttpActionResult Get(int id)
        {
            try
            {
                var hotel = _hotelManager.GetHotel(id); //Throws an exception if the hotel is not found

                return Ok(hotel);
            }
            catch (Exception a)
            {
                Console.WriteLine(a);
                return NotFound();
            }
        }

        // POST: api/hotels
        public IHttpActionResult Post([FromBody] HotelDto hotelDto)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");

            return Ok(_hotelManager.CreateHotel(hotelDto));
        }

    }
}
