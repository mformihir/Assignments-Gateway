﻿using System;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;
using HMS.BAL;
using HMS.Models;
using HMS.Models.Dtos;
namespace HMS.WebApi.Controllers
{
    [Authorize]
    public class BookingController : ApiController
    {
        private readonly IBookingManager _bookingManager;

        public BookingController(IBookingManager bookingManager)
        {
            _bookingManager = bookingManager;
        }

        // GET: api/booking/5
        [Route("api/booking/{id:int}")]
        [ResponseType(typeof(BookingDto))]
        public IHttpActionResult GetBooking(int id)
        {
            BookingDto bookingDto = _bookingManager.GetBooking(id);
            if (bookingDto == null)
            {
                return NotFound();
            }

            return Ok(bookingDto);
        }
        // GET: api/booking
        [Route("api/booking/")]
        [HttpGet]
        public IHttpActionResult GetBookings()
        {
            var bookings = _bookingManager.GetBookings();

            if (!bookings.Any())
                return NotFound();

            return Ok(bookings);
        }

        //// PUT: api/booking/
        [Route("api/booking/{bookingId:int}/{updatedDate:datetime}")]
        [ResponseType(typeof(void))]
        [HttpPut]
        public IHttpActionResult UpdateBookingDate(int bookingId, DateTime updatedDate)
        {
            string result = _bookingManager.UpdateBooking(bookingId, updatedDate);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);

        }

        //// PUT: api/booking/
        [Route("api/booking/{bookingId:int}/{bookingStatus}")]
        [ResponseType(typeof(void))]
        [HttpPut]
        public IHttpActionResult UpdateBookingStatus(int bookingId, Status bookingStatus)
        {
            if (!(bookingStatus == Status.Definitive || bookingStatus == Status.Cancelled)) //if the updated bookingStatus is not Definitive nor Cancelled
            {
                return BadRequest("Invalid booking status.");
            }

            string result = _bookingManager.UpdateBookingStatus(bookingId, bookingStatus);


            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);

        }

        // POST: api/booking
        [Route("api/booking/{roomId:int}/{bookingDate:datetime}")]
        [ResponseType(typeof(BookingDto))]
        public IHttpActionResult PostBooking(int roomId, DateTime bookingDate)
        {
            try
            {
                return Ok(_bookingManager.BookRoom(roomId, bookingDate));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return NotFound();
            }
        }

        //// DELETE: api/booking/1
        [Route("api/booking/{bookingId:int}")]
        [ResponseType(typeof(void))]
        [HttpDelete]
        public IHttpActionResult DeleteBooking(int bookingId)
        {
            string result = _bookingManager.DeleteBooking(bookingId);
            if (result == null)
            {
                return NotFound();
            }

            if (result == "Success.")
            {
                return Ok(result);
            }

            return InternalServerError();
        }

    }
}