﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Models;
using HMS.Models.Dtos;

namespace HMS.DAL.Repository
{
    public interface IBookingRepository
    {
        BookingDto GetBooking(int id);
        string BookRoom(int roomId, DateTime bookingDate);
        IQueryable<BookingDto> GetBookings();
        string UpdateBooking(int bookingId, DateTime updatedDate);
        string UpdateBookingStatus(int id, Status bookingStatus);
        string DeleteBooking(int id);
    }
}
