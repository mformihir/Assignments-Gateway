﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using HMS.DAL.Database;
using HMS.Models;
using HMS.Models.Dtos;

namespace HMS.DAL.Repository
{
    public class BookingRepository : IBookingRepository
    {
        private readonly HotelContext _dbContext;
        private IMapper mapper;
        private MapperConfiguration config;

        public BookingRepository()
        {
            _dbContext = new HotelContext();

            config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Booking, BookingDto>();
                cfg.CreateMap<BookingDto, Booking>();
            });

            mapper = config.CreateMapper();
        }

        public BookingDto GetBooking(int id)
        {
            var booking = _dbContext.Bookings.Find(id);
            var bookingDto = mapper.Map<BookingDto>(booking);
            return bookingDto;
        }

        public IQueryable<BookingDto> GetBookings()
        {
            return _dbContext.Bookings.ToList().AsQueryable().ProjectTo<BookingDto>(config);
        }

        public string BookRoom(int roomId, DateTime bookingDate)
        {
            var isValidRoomId = _dbContext.Rooms.Where(b => b.Id == roomId).Single(); //throws an exception if roomId is invalid

            //check if the room is already booked
            var bookingCount = _dbContext.Bookings.Where(b => b.RoomId == roomId && b.Date == bookingDate && b.Status != Status.Deleted).Count();
            if (bookingCount != 0)
                return "Room is already booked on the specified date.";

            var booking = new Booking();
            booking.RoomId = roomId;
            booking.Date = bookingDate;
            booking.Status = Status.Optional;

            _dbContext.Bookings.Add(booking);
            _dbContext.SaveChanges();
            return $"Success. BookingId: {booking.Id}";
        }

        public string UpdateBooking(int bookingId, DateTime updatedDate)
        {
            try
            {
                var bookingInDb = _dbContext.Bookings.SingleOrDefault(b => b.Id == bookingId);
                if (bookingInDb == null)
                {
                    return null;
                }

                if (bookingInDb.Status == Status.Deleted)
                {
                    return null;
                }

                //check if there are bookings already
                var bookingCount = _dbContext.Bookings.Where(b => b.Id == bookingId && b.Date == updatedDate && b.Status != Status.Deleted).Count();

                if (bookingCount != 0)
                    return "The room is already booked on the specified date.";

                bookingInDb.Date = updatedDate;
                _dbContext.Entry(bookingInDb).State = EntityState.Modified;
                _dbContext.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return e.Message;
            }

            return "Success.";
        }

        public string UpdateBookingStatus(int id, Status bookingStatus)
        {
            try
            {
                var bookingInDb = _dbContext.Bookings.SingleOrDefault(b => b.Id == id);
                if (bookingInDb == null)
                {
                    return null;
                }

                if (bookingInDb.Status == Status.Deleted)
                    return null;

                bookingInDb.Status = bookingStatus;
                _dbContext.Entry(bookingInDb).State = EntityState.Modified;
                _dbContext.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return e.Message;
            }

            return "Success.";
        }
        public string DeleteBooking(int id)
        {
            try
            {
                var bookingInDb = _dbContext.Bookings.SingleOrDefault(b => b.Id == id);
                if (bookingInDb == null)
                {
                    return null;
                }
                bookingInDb.Status = Status.Deleted;
                _dbContext.Entry(bookingInDb).State = EntityState.Modified;
                _dbContext.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return e.Message;
            }

            return "Success.";
        }

    }
}
