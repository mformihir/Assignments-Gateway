﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using HMS.DAL.Database;
using HMS.Models;
using HMS.Models.Dtos;
using Category = HMS.Models.Category;

namespace HMS.DAL.Repository
{
    public class RoomRepository : IRoomRepository
    {
        private readonly HotelContext _dbContext;
        private IMapper mapper;
        private MapperConfiguration config;

        public RoomRepository()
        {
            _dbContext = new HotelContext();

            config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Room, RoomDto>();
                cfg.CreateMap<RoomDto, Room>();
                cfg.CreateMap<BookingDto, Booking>();
                cfg.CreateMap<Booking, BookingDto>();
            });

            mapper = config.CreateMapper();
        }
        public RoomDto GetRoom(int id)
        {
            try
            {
                var room = _dbContext.Rooms.Include(b => b.Bookings).Where(r => r.Id == id).Single();
                var roomDto = mapper.Map<Room, RoomDto>(room);
                return roomDto;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public IQueryable<RoomDto> GetRooms()
        {
            var roomDtos = _dbContext.Rooms.OrderBy(h => h.Price).Include(r => r.Bookings).Where(h => h.IsActive).Select(mapper.Map<Room, RoomDto>);
            return roomDtos.AsQueryable();
        }

        public IQueryable<RoomDto> GetRoomsByCity(string hotelCity)
        {
            var roomDtos = _dbContext.Rooms.OrderBy(h => h.Price).Where(h => h.IsActive && h.Hotel.City.Contains(hotelCity.ToLower())).Select(mapper.Map<Room, RoomDto>);
            return roomDtos.AsQueryable();
        }
        public IQueryable<RoomDto> GetRoomsByPinCode(string pinCode)
        {
            var roomDtos = _dbContext.Rooms.OrderBy(h => h.Price).Where(h => h.IsActive && h.Hotel.PinCode.Contains(pinCode.ToLower())).Select(mapper.Map<Room, RoomDto>);
            return roomDtos.AsQueryable();
        }

        public IQueryable<RoomDto> GetRoomsByPrice(decimal price)
        {
            var roomDtos = _dbContext.Rooms.OrderBy(h => h.Price).Where(h => h.IsActive && h.Price == price).Select(mapper.Map<Room, RoomDto>);
            return roomDtos.AsQueryable();
        }

        public IQueryable<RoomDto> GetRoomsByCategory(Category category)
        {
            var roomDtos = _dbContext.Rooms.OrderBy(h => h.Price).Where(h => h.IsActive && h.Category == category).Select(mapper.Map<Room, RoomDto>);
            return roomDtos.AsQueryable();
        }

        public string CreateRoom(RoomDto roomDto)
        {
            try
            {
                var room = mapper.Map<Room>(roomDto);

                //Adding data for project-specific fields
                room.CreatedDate = DateTime.Today;
                room.CreatedBy = 1;

                _dbContext.Rooms.Add(room);
                _dbContext.SaveChanges();
                return "Success";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public bool CheckAvailability(int roomId, DateTime checkDate)
        {
            //check if roomId is a valid roomId
            var isValidRoomId = _dbContext.Rooms.Where(b => b.Id == roomId).Single(); //throws an exception if roomId is invalid

            var bookingCount = _dbContext.Bookings.Where(b => b.RoomId == roomId && b.Date == checkDate && b.Status != Status.Deleted).Count();
            if (bookingCount != 0)
                return false;
            return true;
        }
    }
}
