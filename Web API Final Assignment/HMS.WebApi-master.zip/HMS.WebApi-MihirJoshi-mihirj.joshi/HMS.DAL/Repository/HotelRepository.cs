﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using HMS.DAL.Database;
using HMS.Models;
using HMS.Models.Dtos;

namespace HMS.DAL.Repository
{
    public class HotelRepository : IHotelRepository
    {
        private readonly HotelContext _dbContext;
        public IMapper mapper;
        public MapperConfiguration config;


        public HotelRepository()
        {
            _dbContext = new HotelContext();

            config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Hotel, HotelDto>();
                cfg.CreateMap<HotelDto, Hotel>();
                cfg.CreateMap<Room, RoomDto>();
                cfg.CreateMap<RoomDto, Room>();
            });

            mapper = config.CreateMapper();
        }

        public HotelDto GetHotel(int id)
        {
            try
            {
                var hotel = _dbContext.Hotels.Include(r => r.Rooms).Where(h => h.Id == id).Single();
                var hotelDto = mapper.Map<Hotel, HotelDto>(hotel);
                return hotelDto;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public IQueryable<HotelDto> GetHotels()
        {
            var hotelDtos = _dbContext.Hotels.OrderBy(h => h.Name).Include(r => r.Rooms).Where(h => h.IsActive).Select(mapper.Map<Hotel, HotelDto>);

            return hotelDtos.AsQueryable();
            //Uncomment the following line to not include Rooms with Hotel Objects
            //return _dbContext.Hotels.OrderBy(h => h.Name);
        }

        public string CreateHotel(HotelDto hotelDto)
        {
            try
            {
                var hotel = mapper.Map<Hotel>(hotelDto);

                //Adding data for project-specific fields
                hotel.CreatedDate = DateTime.Today;
                hotel.CreatedBy = 1;

                _dbContext.Hotels.Add(hotel);
                _dbContext.SaveChanges();

                //Adding hotelId to HotelDto object, to be used by RoomDto
                hotelDto.Id = hotel.Id;

                return "Success";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
    }
}
