﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Models;
using HMS.Models.Dtos;
using Category = HMS.Models.Category;

namespace HMS.DAL.Repository
{
    public interface IRoomRepository
    {
        RoomDto GetRoom(int id);
        IQueryable<RoomDto> GetRooms();
        IQueryable<RoomDto> GetRoomsByCity(string hotelCity);
        IQueryable<RoomDto> GetRoomsByPinCode(string pinCode);
        IQueryable<RoomDto> GetRoomsByPrice(decimal price);
        IQueryable<RoomDto> GetRoomsByCategory(Category category);
        string CreateRoom(RoomDto roomDto);
        bool CheckAvailability(int roomId, DateTime checkDate);
    }
}
