﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Models;

namespace HMS.DAL.Database
{
    class HotelInitializer : DropCreateDatabaseIfModelChanges<HotelContext>
    {
        protected override void Seed(HotelContext context)
        {
            var hotels = new List<Hotel>
            {
                new Hotel
                {
                    Name = "Test Hotel",
                    Address = "New York, New York",
                    City = "New York City",
                    PinCode = "111222",
                    ContactNumber = "1234",
                    ContactPerson = "John",
                    Website = "www.google.com",
                    Facebook = "www.facebook.com",
                    Twitter = "www.twitter.com",
                    IsActive = true,
                    CreatedDate = DateTime.Today,
                    CreatedBy = 1,
                }
            };

            hotels.ForEach(h => context.Hotels.Add(h));
            context.SaveChanges();

            //base.Seed(context);
        }
    }
}
