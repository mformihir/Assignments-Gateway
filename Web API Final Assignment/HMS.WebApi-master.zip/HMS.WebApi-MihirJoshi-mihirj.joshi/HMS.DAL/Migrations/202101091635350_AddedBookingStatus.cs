﻿namespace HMS.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedBookingStatus : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Booking", "Status", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Booking", "Status", c => c.String());
        }
    }
}
