﻿namespace HMS.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AllowNullsInCreatedUpdatedRooms : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Room", "CreatedBy", c => c.Int());
            AlterColumn("dbo.Room", "UpdatedBy", c => c.Int());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Room", "UpdatedBy", c => c.Int(nullable: false));
            AlterColumn("dbo.Room", "CreatedBy", c => c.Int(nullable: false));
        }
    }
}
