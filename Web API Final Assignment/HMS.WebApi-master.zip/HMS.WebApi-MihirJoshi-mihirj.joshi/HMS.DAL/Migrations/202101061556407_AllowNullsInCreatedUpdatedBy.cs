﻿namespace HMS.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AllowNullsInCreatedUpdatedBy : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Hotel", "CreatedBy", c => c.Int());
            AlterColumn("dbo.Hotel", "UpdatedBy", c => c.Int());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Hotel", "UpdatedBy", c => c.Int(nullable: false));
            AlterColumn("dbo.Hotel", "CreatedBy", c => c.Int(nullable: false));
        }
    }
}
